/* Login-page script (no JWT). Uses window.HanyePlugin SDK. */
;(function () {
  var P = window.HanyePlugin
  if (!P) return

  P.registerSlot(
    'login.header',
    function (el) {
      el.innerHTML =
        '<div style="text-align:center;margin-bottom:8px;padding:8px 12px;border-radius:8px;background:linear-gradient(90deg,#0ea5e9,#6366f1);color:#fff;font-weight:600">插件已接管登录页抬头</div>'
    },
    { order: 0, plugin: 'demo_hello' }
  )

  P.registerSlot(
    'login.form.after',
    '<p style="margin:12px 0 0;font-size:12px;opacity:.75;text-align:center">由 demo_hello 插件注入 · 可改任意登录 UI</p>',
    { order: 10 }
  )

  P.patchTheme({
    /* appearance store keys optional */
  })
})()
